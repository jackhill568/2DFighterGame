from configs import *
from game_classes import UserInterface
from Offline import Offline_game
from Online import online_player
import pygame

pygame.init()
clock = pygame.time.Clock()

if __name__ == '__main__':
    UI = UserInterface()
    UI.main_loop()

    while not UI.stop:
        UI.run = True

        if not UI.start:
            if UI.online:
                UI.wait_screen()
                player = online_player(UI.screen, UI.connection, 250, 50, UI.characterChoice, RESOLUTIONS[UI.RES_SET])
                while player.game:

                    player.update()
                    clock.tick(60)

            else:
                game = Offline_game(UI.screen, UI.characterChoice, RESOLUTIONS[UI.RES_SET])
                game.main_loop()
        UI.main_loop()

pygame.quit()







