from game_classes import *


class Offline_game():

    def __init__(self, surface, playerChoice, resolution):
        self.screen = surface
        self.resolution = resolution
        self.surface = pygame.Surface(RESOLUTIONS[0])
        self.player_1 = player(self.surface, None, 50, 60, playerChoice, resolution)
        self.run = True

        self.clock = pygame.time.Clock()
        self.enemy = offline_player(self.surface, 1500, 60, (not playerChoice), resolution)
        self.pause = False
        self.tresume = Tab(self.surface, tab_Colour, tab_selectColour, WIDTH/2, 10, t_WIDTH, t_HEIGHT, "resume", self.resume)
        self.texit = Tab(self.surface, tab_Colour, tab_selectColour, WIDTH/2, 60, t_WIDTH, t_HEIGHT, "exit", self.exit)
        self.tabs = [self.tresume, self.texit]
        self.current = 0


    def exit(self):
        self.run = False

    def resume(self):
        self.pause = False

    def main_loop(self):
        while self.run:
            # self.surface.blit(self.bg, (0,0))
            self.surface.fill("white")
            self.clock.tick(60)

            self.player_1.update()
            self.enemy.update()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.run = False

                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_SPACE:
                        self.player_1.jump_key_down = False
                    if event.key == pygame.K_a or pygame.K_d:
                        self.player_1.state[1] = 0
                    if event.key == pygame.K_l:
                        self.player_1.dash_key_down = False
                    if event.key == pygame.K_ESCAPE:
                        self.pause = True
                    if event.key == pygame.K_j:
                        self.player_1.attack_key_down = False

                if self.pause:
                    if event.type == pygame.KEYDOWN:
                        key = pygame.key.get_pressed()
                        if key[pygame.K_DOWN]:
                            if self.current < len(self.tabs)-1:
                                self.current += 1
                            else:
                                self.current = 0
                        if key[pygame.K_UP]:
                            if 0 < self.current:
                                self.current -= 1
                            else:
                                self.current = 1
                        if key[pygame.K_RETURN] or key[pygame.K_j] or key[pygame.K_SPACE]:
                            self.tabs[self.current].func()
            if self.pause:
                # pygame.draw.rect(self.surface, "black", (WIDTH/2 - 10, 5, 230, 150))
                for t in self.tabs:
                    if self.tabs.index(t) == self.current:
                        t.hover()
                    else:
                        t.draw()
            self.screen.blit(pygame.transform.scale(self.surface, self.resolution), (0,0))
            pygame.display.update()


class offline_player(player):

    def __init__(self, surface, x, y, sprite_type, resolution):
        super().__init__(surface, None, x, y, sprite_type, resolution)

    def movement_input(self, collison):

        if "down" in collison:
            self.state = [1, 0, self.state[2], 0, 0, 0]
        else:
            self.state = [0, 0, self.state[2], 1, 0, 0]

        if self.state[1] == 0 and self.state[4] == 0:
            if self.vel.x != 0:
                if self.vel.x < 0:
                    self.vel.x += 0.25 * ACCELERATION
                else:
                    self.vel.x -= 0.25 * ACCELERATION
            if self.vel.y != 0:
                if self.vel.y < 0:
                    self.vel.y += 0.25 * ACCELERATION
                else:
                    self.vel.y -= 0.25 * ACCELERATION
            self.vel.x = self.vel.x.__round__(1)
            self.vel.y = self.vel.y.__round__(1)

