import pygame.time

from game_classes import *


class server_player:

    def __init__(self, connection, x, y, sprite_type, size):
        self.sprite_type = sprite_type
        self.connection = connection
        self.size = size
        self.game = True
        self.collision = []
        self.key = [False, False, False, False, False, False, False]
        self.position = pygame.math.Vector2(x, y)
        self.vel = pygame.math.Vector2(0, 0)
        self.acc = pygame.math.Vector2(0, 0)
        self.jump_vel = pygame.math.Vector2(0, 0)
        self.jumps_options = 2
        self.dash_key_down = False
        self.state = [0, 2, 0, 1, 0, 0]
        self.down = False
        self.direction = False
        self.is_dashing = False
        self.jump_key_down = False
        self.active_jump = False
        self.Y_INITIAL = 0
        self.X_INITIAL = 0

    def wall_collision(self):
        # 0: none, 1: left, 2: right, 3:down, 4: up
        wall_collision = []
        if self.position.x <= 0.5 * self.size[0]:
            self.position.x = 0.5 * self.size[0]
            self.vel.x = 0

            wall_collision.append("left")
        if self.position.y <= 0.5 * self.size[1]:
            self.position.y = 0.5 * self.size[1]
            self.vel.y = 0
            wall_collision.append("up")
        if self.position.x >= WIDTH - 0.5 * self.size[0]:
            self.position.x = WIDTH - 0.5 * self.size[0]
            self.vel.x = 0
            wall_collision.append("right")
        if self.position.y >= HEIGHT - 0.5 * self.size[1]:
            self.position.y = HEIGHT - 0.5 * self.size[1]
            self.vel.y = 0
            wall_collision.append("down")
        self.collision = wall_collision

    def movement_calc(self):
        #keys stuff 0: a, 1:d, 2:w, 3:s, 4:space, 5:l, 6:j
        # state 0:idle, 1: moving, 2: jumping, 3: falling, 4:fast-falling, 5:dashing, 6:collision
        self.state = self.state
        if self.collision:
            limit = 6
        else:
            limit = 4
        if "down" in self.collision:
            self.state = [1, self.state[1], self.state[2], 0, 0, 0]
        else:
            self.state = [0, 0, self.state[2], 1, 0, 0]

        if self.key[4]:
            if self.vel.y > -1 and self.jumps_options != 0 and "up" not in self.collision and not self.jump_key_down:
                self.vel.y = 0
                self.state[2] = 1
                self.state[0] = 0
                self.jump_key_down = True
                self.jumps_options -= 1
                self.Y_INITIAL = self.position.y

        if self.key[3]:
            if self.vel.y < 15 and "down" not in self.collision:
                self.acc.y = ACCELERATION
                self.state[4] = 1
                self.state[0] = 0
                self.state[2] = 0

        if self.key[0]:
            if self.vel.x > -limit and "left" not in self.collision:
                self.acc.x = -ACCELERATION
                self.state[1] = 1
                self.state[0] = 0
                self.direction = False

        if self.key[1]:
            if self.vel.x < limit and "right" not in self.collision:
                self.acc.x = ACCELERATION
                self.state[1] = 2
                self.state[0] = 0
                self.direction = True

        if self.key[5]:
            if not self.dash_key_down and ("left" not in self.collision or "right" not in self.collision) and "down" in self.collision and \
                    self.state[1] != 0:
                self.state[5] = 1
                self.state[0] = 0
                self.dash_key_down = True
                self.X_INITIAL = self.position.x
                self.INITIAL_direction = self.direction

        if self.state[1] == 0 and self.state[4] == 0:
            if self.vel.x != 0:
                if self.vel.x < 0:
                    self.vel.x += 0.25 * ACCELERATION
                else:
                    self.vel.x -= 0.25 * ACCELERATION
            if self.vel.y != 0:
                if self.vel.y < 0:
                    self.vel.y += 0.25 * ACCELERATION
                else:
                    self.vel.y -= 0.25 * ACCELERATION

    def gravity(self):
        if self.vel.y < 10 and self.state[2] == 0 and "down" not in self.collision:
            self.acc.y += 0.5 * ACCELERATION


    def dash_deceleration(self):
        if self.state[5] == 1:
            if self.state[1] == 1:
                if self.vel.x < 5:
                    self.acc.x = -10 * ACCELERATION
                    if self.X_INITIAL - self.position.x >= 300 or self.collision or self.direction:
                        self.state[5] = 0
                        self.vel.x = -2.5
            elif self.state[1] == 2:
                if self.vel.x > -5:
                    self.acc.x = 10 * ACCELERATION
                    if self.position.x - self.X_INITIAL >= 300 or self.collision or not self.direction:
                        self.state[5] = 0
                        self.vel.x = 2.5

    def jump_deceleration(self):
        if self.state[2] == 1:
            self.acc.y = -1

            if self.Y_INITIAL - self.position.y >= 60 or "left" in self.collision or "right" in self.collision:
                self.state[2] = 0

    def jumps_update(self):
        if "down" in self.collision:
            self.jumps_options = 3
        elif "left" in self.collision or "right" in self.collision:
            self.jumps_options = 2



class online_player(player):

    def __init__(self, surface, connection, x, y, sprite_type, resolution):
        super(online_player, self).__init__(surface, connection, x, y, sprite_type, resolution)
        self.game = True
        self.count = 0
        self.collision = []
        # 0: a, 1:d, 2:w, 3:s, 4:space, 5:l, 6:j
        self.key = {97: False, 100: False, 119: False,  115: False, 32: False, 108: False, 106: False}
        self.P2 = player(surface, None, 200, 200, sprite_type, resolution)
        self.P2.collision = []

        self.receiving = threading.Thread(target=self.recv_from_server)
        self.receiving.start()


    def set_data(self, data):
        print(data)
        if data[1][0] == "COLLISION":
            if data[1][1][0] == "DATA_P1":
                self.collision = data[1][1][1]
            else:
                self.P2.collision = data[1][1][1]

        elif data[1][0] == "DATA_P1":
            self.position = pygame.math.Vector2(data[1][1][0], data[1][1][1])
            self.vel = pygame.math.Vector2(data[1][1][2], data[1][1][3])
            self.acc = pygame.math.Vector2(data[1][1][4], data[1][1][5])
            self.state = data[1][1][6]
            self.direction = data[1][1][7]
            self.jumps_options = data[1][1][8]

        elif data[1][0] == "DATA_P2":
            self.P2.position = pygame.math.Vector2(data[1][1][0], data[1][1][1])
            self.P2.vel = pygame.math.Vector2(data[1][1][2], data[1][1][3])
            self.P2.acc = pygame.math.Vector2(data[1][1][4], data[1][1][5])
            self.P2.state = data[1][1][6]
            self.P2.direction = data[1][1][7]
            self.P2.jumps_options = data[1][1][8]


    def recv_from_server(self):
        while True:
            data = self.connection.recv(1024).decode()
            if not data:
                pass
            else:
                data = [i + "}" for i in data.split("}") if i]

                try:
                    for d in data:
                        d = json.loads(d)
                        if d["COMMAND"] == "SET":
                            self.set_data(list(d.items()))
                except:
                    pass



    def update(self):
        self.surface.fill("white")
        for event in pygame.event.get():
            try:
                if event.type == pygame.KEYDOWN:
                    self.key[event.key] = True
                if event.type == pygame.KEYUP:
                    self.key[event.key] = False
                    if event.key == 32:
                        self.connection.send(json.dumps({"COMMAND": "SET", "JUMP_KEY": False}).encode())
                    elif event.key == 108:
                        self.connection.send(json.dumps({"COMMAND": "SET", "DASH_KEY": False}).encode())
            except KeyError:
                print("unrecognised key")

            # 0: a, 1:d, 2:w, 3:s, 4:space, 5:l, 6:j
        self.connection.send(json.dumps({"COMMAND": "SET", "KEY": list(self.key.values())}).encode())
        # 0:idle, 1: moving, 2: jumping, 3: falling, 4:fast-falling, 5:dashing
        # sprites = [idle, run, jump, fall, fast-fall, re-idle, re-run, re-jump, re-fall, re-fast-fall]
        self.rect.center = self.position
        self.animate(self.collision,  self.sheets, self.vel, self.state, self.direction)
        self.surface.blit(self.image, self.rect)

        self.P2.rect.center = self.P2.position
        self.P2.animate(self.P2.collision, self.P2.sheets, self.P2.vel, self.P2.state, self.P2.direction)
        self.surface.blit(self.P2.image, self.P2.rect)

        pygame.display.update()



class Server_game:
    def __init__(self, clients):
        self.count = 0
        self.clock = pygame.time.Clock()
        self.clients = clients # where clients is list of dictionarys with connections and data from character choice etc
        if clients[0]["characterChoice"]:
            self.playerOne = server_player(self.clients[0]["connection"], 200, 50, self.clients[0]["characterChoice"], (52, 45))
        else:
            self.playerOne = server_player(self.clients[0]["connection"], 200, 50, self.clients[0]["characterChoice"], (52, 45))

        if clients[1]["characterChoice"]:
            self.playerTwo = server_player(self.clients[1]["connection"], 200, 50, self.clients[1]["characterChoice"], (52,45))
        else:
            self.playerTwo = server_player(self.clients[1]["connection"], 200, 50, self.clients[1]["characterChoice"], (52, 45))
            # surface, connection, x, y, sprite_type, resolution

        self.game = True
        self.receiving = threading.Thread(target=self.recv_from_clients)
        self.receiving.start()

    def set_data(self, connection, data):
        print(data)
        if connection == self.playerOne.connection:
            if data[1][0] == "KEY":
                self.playerOne.key = data[1][1]
            elif data[1][0] == "JUMP_KEY":
                self.playerOne.jump_key_down = False
            elif data[1][0] == "DASH_KEY":
                self.playerOne.dash_key_down = False
        else:
            if data[1][0] == "KEY":
                self.playerTwo.key = data[1][1]
            elif data[1][0] == "JUMP_KEY":
                self.playerTwo.jump_key_down = False
            elif data[1][0] == "DASH_KEY":
                self.playerTwo.dash_key_down = False


    def send_to_client(self, client, message):
        client.send(json.dumps(message).encode())

    def recv_from_clients(self):
        while True:
            for client in self.clients:
                data = client["connection"].recv(2048).decode()
                if not data:
                    pass
                else:
                    self.data = [i+"}" for i in data.split("}") if i]
                    try:
                        for data in self.data:
                            data = json.loads(data)
                            if data["COMMAND"] == "SET":
                                self.set_data(client["connection"], list(data.items()))
                    except:
                        pass
                    # self.data = json.loads(data)
                    # if self.data["COMMAND"] == "SET":
                    #     self.set_data(client["connection"], data.items())
                    # try/except to catch broken ones

    def main_loop(self):
        self.clock.tick(60)
        self.playerOne.wall_collision()
        self.playerTwo.wall_collision()

        self.send_to_client(self.playerOne.connection, {"COMMAND": "SET", "COLLISION": ["DATA_P1", self.playerOne.collision]})
        self.send_to_client(self.playerTwo.connection, {"COMMAND": "SET", "COLLISION": ["DATA_P1", self.playerTwo.collision]})

        self.send_to_client(self.playerTwo.connection, {"COMMAND": "SET", "COLLISION": ["DATA_P2", self.playerOne.collision]})
        self.send_to_client(self.playerOne.connection, {"COMMAND": "SET", "COLLISION": ["DATA_P2", self.playerTwo.collision]})

        self.playerOne.movement_calc()
        self.playerTwo.movement_calc()


        self.playerOne.dash_deceleration()
        self.playerOne.gravity()
        self.playerOne.jump_deceleration()

        self.playerTwo.dash_deceleration()
        self.playerTwo.gravity()
        self.playerTwo.jump_deceleration()

        self.playerOne.vel += self.playerOne.acc
        self.playerOne.position += self.playerOne.vel

        self.playerTwo.vel += self.playerTwo.acc
        self.playerTwo.position += self.playerTwo.vel

        self.playerOne.acc = pygame.math.Vector2(0, 0)
        self.playerTwo.acc = pygame.math.Vector2(0, 0)

        self.playerOne.jumps_update()
        self.playerTwo.jumps_update()

        playerOneData = [self.playerOne.position.x, self.playerOne.position.y, self.playerOne.vel.x, self.playerOne.vel.y, self.playerOne.acc.x, self.playerOne.acc.y, self.playerOne.state, self.playerOne.direction, self.playerOne.jumps_options]
        playerTwoData = [self.playerTwo.position.x, self.playerTwo.position.y, self.playerTwo.vel.x, self.playerTwo.vel.y, self.playerTwo.acc.x, self.playerTwo.acc.y, self.playerTwo.state, self.playerTwo.direction, self.playerTwo.jumps_options]

        self.send_to_client(self.playerOne.connection, {"COMMAND": "SET", "DATA_P1":playerOneData})
        self.send_to_client(self.playerTwo.connection, {"COMMAND": "SET", "DATA_P1":playerTwoData})
        self.send_to_client(self.playerOne.connection, {"COMMAND": "SET", "DATA_P2": playerTwoData})
        self.send_to_client(self.playerTwo.connection, {"COMMAND": "SET", "DATA_P2": playerOneData})

        # need to revolutionise player class to work online, func gets passed player input and returns player state and position
        # including vel and acc to make animations work smooth
        # need a func to handle player inputs from client server file to pass into this one big dict in order somewhere




