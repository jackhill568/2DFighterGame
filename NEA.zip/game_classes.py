import random
import socket
import threading
import time

import pygame.display

from configs import *
from pygame._sdl2 import Window
import json


class hitbox(pygame.sprite.Sprite):

    def __init__(self, x, y, width, height):
        super().__init__()
        self.x = x
        self.y = y
        self.width = width
        self.height = height


class Tab:

    def __init__(self, surface, colour, select_colour, x, y, width, height, message, func):

        self.rect = pygame.Rect(x, y, width, height)
        self.surface = surface
        self.colour = colour
        self.selectColour = select_colour
        self.message = message
        self.func = func

    def hover(self):
        # pygame.draw.rect(self.surface, self.selectColour, self.rect)
        self.surface.blit(pygame.font.SysFont("Comic sans ms", 25).render(self.message, True, (random.randint(1, 254), random.randint(1, 254), random.randint(1, 254))), (self.rect.x + 5, self.rect.y + 5))


    def draw(self):
        # pygame.draw.rect(self.surface, self.colour, self.rect)
        self.surface.blit(pygame.font.SysFont("Comic sans ms", 25).render(self.message, True, "black"), (self.rect.x + 5, self.rect.y + 5))

class player:

    def __init__(self, surface, connection, x, y, sprite_type, resolution):

        self.connection = connection
        self.x = x
        self.y = y
        self.surface = surface
        self.resolution = resolution

        self.sheets = {
            "idle": {"numberOfFrames": sully_info[0][0], "frameOffset": sully_info[0][1], "width": sully_info[0][2], "height": sully_info[0][3], "xOffset": sully_info[0][4], "xDisposition": sully_info[0][5], "yDisposition": sully_info[0][6], "sheet":pygame.image.load(sully_info[0][7]).convert_alpha()},
            "run": {"numberOfFrames": sully_info[1][0], "frameOffset": sully_info[1][1], "width": sully_info[1][2], "height": sully_info[1][3], "xOffset": sully_info[1][4], "xDisposition": sully_info[1][5], "yDisposition": sully_info[1][6], "sheet":pygame.image.load(sully_info[1][7]).convert_alpha()},
            "jump": {"numberOfFrames": sully_info[2][0], "frameOffset": sully_info[2][1], "width": sully_info[2][2], "height": sully_info[2][3], "xOffset": sully_info[2][4], "xDisposition": sully_info[2][5], "yDisposition": sully_info[2][6], "sheet":pygame.image.load(sully_info[2][7]).convert_alpha()},
            "fall": {"numberOfFrames": sully_info[3][0], "frameOffset": sully_info[3][1], "width": sully_info[3][2], "height": sully_info[3][3], "xOffset": sully_info[3][4], "xDisposition": sully_info[3][5], "yDisposition": sully_info[3][6], "sheet":pygame.image.load(sully_info[3][7]).convert_alpha()},
            "fast-fall": {"numberOfFrames": sully_info[4][0], "frameOffset": sully_info[4][1], "width": sully_info[4][2], "height": sully_info[4][3], "xOffset": sully_info[4][4], "xDisposition": sully_info[4][5], "yDisposition": sully_info[4][6], "sheet":pygame.image.load(sully_info[4][7]).convert_alpha()},
            "sideGroundAtk": {"numberOfFrames": sully_info[5][0], "frameOffset": sully_info[5][1], "width": sully_info[5][2], "height": sully_info[5][3], "xOffset": sully_info[5][4], "xDisposition": sully_info[5][5], "yDisposition": sully_info[5][6], "sheet":pygame.image.load(sully_info[5][7]).convert_alpha()}
            }

        self.state = [0, 2, 0, 1, 0, 0]#0:idle, 1: moving, 2: jumping, 3: falling, 4:fast-falling, 5:dashing
        self.attack_state = [0, 0, 0]
        self.image = None
        self.sprites = []
        self.locked_animation = []

        for animation in self.sheets:
            self.sheets[animation]["sheet"] = self.__get_sprites(self.sheets[animation])
            self.sheets[animation]["reSheet"] = self.get_flip_sprite(self.sheets[animation]["sheet"])

        # self.get_flip_sprite(self.sprites[0])
        # self.get_flip_sprite(self.sprites[1])
        # self.get_flip_sprite(self.sprites[2])
        # self.get_flip_sprite(self.sprites[3])
        # self.get_flip_sprite(self.sprites[4])
        # self.get_flip_sprite(self.sprites[5])


        # sprites = [idle, run, jump, fall, fast-fall, slight, re-idle, re-run, re-jump, re-fall, re-fast-fall, reSlight]
        self.animation_state = []
        self.image = self.sprites[0][0]
        # self.animate(self.animation_state[0], 0)
        self.position = pygame.math.Vector2(self.x, self.y)
        self.rect = self.image.get_rect(center=self.position)
        self.vel = pygame.math.Vector2(0, 0)
        self.acc = pygame.math.Vector2(0, 0)
        self.jump_vel = pygame.math.Vector2(0, 0)
        self.jumps_options = 2
        self.dash_key_down = False
        self.down = False
        self.direction = False
        self.is_dashing = False
        self.jump_key_down = False
        self.active_jump = False
        self.attack_key_down = False
        self.Y_INITIAL = 0
        self.X_INITIAL = 0
        self.frame = 0
        self.last_animation = 0

        self.sprites = {
            "idle": self.sprites[0],
            "run": self.sprites[1],
            "jump": self.sprites[2],
            "fall": self.sprites[3],
            "fast-fall": self.sprites[4],
            "slight": self.sprites[5],
            "reIdle": self.sprites[6],
            "reRun": self.sprites[7],
            "reJump": self.sprites[8],
            "reFall": self.sprites[9],
            "reFast-fall": self.sprites[10],
            "reSlight": self.sprites[11]
        }

    def __get_sprites(self, sheet):
        sprites = []
        for i in range(0, sheet["numberOfFrames"]):
            image = pygame.Surface((sheet["width"], sheet["height"])).convert_alpha()
            colourkey = image.get_at((0,0))
            image.set_colorkey(colourkey)
            image.blit(sheet["sheet"], (0, 0), (i * (sheet["width"]+sheet["xOffset"]+sheet["xDisposition"]) + sheet["xDisposition"], sheet["yDisposition"], sheet["width"], sheet["height"]))
            sprites.append(image)
        self.sprites.append(sprites)
        return sprites

    def get_flip_sprite(self, sprites):
        temp = []
        for img in sprites:
            temp.append(pygame.transform.flip(img, True, False).convert_alpha())
        self.sprites.append(temp)
        return temp

    def animate(self, wall_collision, sheets, vel, state, direction):
        if direction:
            animation_sheet = sheets["idle"]["sheet"]
        else:
            animation_sheet = sheets["idle"]["reSheet"]

        frame_step = sheets["idle"]["frameOffset"]
        num_of_frames = sheets["idle"]["numberOfFrames"]
        # STATE --> 0:idle, 1: moving, 2: jumping, 3: falling, 4:fast-falling, 5:dashing

        if self.state[1] != 0:
            # run animation
            if direction:
                animation_sheet = sheets["run"]["sheet"]
            else:
                animation_sheet = sheets["run"]["reSheet"]
            frame_step = sheets["run"]["frameOffset"]
            num_of_frames = sheets["run"]["numberOfFrames"]

        if self.state[3] and not wall_collision:
            # fall animation
            if direction:
                animation_sheet = sheets["fall"]["sheet"]
            else:
                animation_sheet = sheets["fall"]["reSheet"]
            frame_step = sheets["fall"]["frameOffset"]
            num_of_frames = sheets["fall"]["numberOfFrames"]
        if self.state[4]:
            #fast fall animation
            if direction:
                animation_sheet = sheets["fast-fall"]["sheet"]
            else:
                animation_sheet = sheets["fast-fall"]["reSheet"]
            frame_step = sheets["fast-fall"]["frameOffset"]
            num_of_frames = sheets["fast-fall"]["numberOfFrames"]
        if self.state[2]:
            # jump animation
            if direction:
                animation_sheet = sheets["jump"]["sheet"]
            else:
                animation_sheet = sheets["jump"]["reSheet"]
            frame_step = sheets["jump"]["frameOffset"]
            num_of_frames = sheets["jump"]["numberOfFrames"]
        if self.attack_state[0] == 1:

            # attack animation
            if direction:
                animation_sheet = sheets["sideGroundAtk"]["sheet"]
            else:
                animation_sheet = sheets["sideGroundAtk"]["reSheet"]
            frame_step = sheets["sideGroundAtk"]["frameOffset"]
            num_of_frames = sheets["sideGroundAtk"]["numberOfFrames"]

        self.frame += frame_step

        if num_of_frames != self.last_animation:
            self.frame = 0
        if int(self.frame) >= num_of_frames:
            self.frame = 0
            if self.attack_state[0]:
                self.attack_state[0] = 0

        self.image = animation_sheet[int(self.frame)]
        self.last_animation = num_of_frames

            # animation state[0] is number of frames in animation
            # animation state[1] is speed to change the frame at
            # animation state[2] is the list of images
            # sprites = [idle, run, jump, fall, fast-fall, slight, re-idle, re-run, re-jump, re-fall, re-fast-fall, reSlight]

    def Get_hitbox(self):

        if self.attack_state[0] == 1 and int(self.frame) == 6:
            slightHitbox = hitbox(self.rect.center[0] + self.rect.w//2, self.rect.h//2, 16, 12)
            pygame.draw.rect(self.surface, "red", (self.rect.center[0] + self.rect.w//2, self.rect.center[1], 16,12))


    def wall_collision(self):
        # 0: none, 1: left, 2: right, 3:down, 4: up
        wall_collision = []
        if self.position.x <= 0.5*self.rect.w:
            self.position.x = 0.5*self.rect.w
            self.vel.x = 0

            wall_collision.append("left")
        if self.position.y <= 0.5*self.rect.h:
            self.position.y = 0.5*self.rect.h
            self.vel.y = 0
            wall_collision.append("up")
        if self.position.x >= WIDTH-0.5*self.rect.w:
            self.position.x = WIDTH-0.5*self.rect.w
            self.vel.x = 0
            wall_collision.append("right")
        if self.position.y >= HEIGHT-0.5*self.rect.h:
            self.position.y = HEIGHT-0.5*self.rect.h + 1
            if not self.state[2]:
                self.vel.y = 0
            wall_collision.append("down")
        return wall_collision

    def movement_input(self, collison):
        # 0:idle, 1: moving, 2: jumping, 3: falling, 4:fast-falling, 5:dashing, 6:collision
        if collison:
            limit = 6
        else:
            limit = 4
        if "down" in collison:
            self.state = [1, self.state[1], self.state[2], 0, 0, 0]
        else:
            self.state = [0, 0, self.state[2], 1, 0, 0]

        key = pygame.key.get_pressed()
        if key[pygame.K_SPACE]:
            if self.vel.y > -1 and self.jumps_options != 0 and "up" not in collison and not self.jump_key_down:
                self.vel.y = 0
                self.state[2] = 1
                self.state[0] = 0
                self.jump_key_down = True
                self.Y_INITIAL = self.position.y
                self.jumps_options -= 1

        if key[pygame.K_s]:
            if self.vel.y < 15 and "down" not in collison:
                self.acc.y = ACCELERATION
                self.state[4] = 1
                self.state[0] = 0
                self.state[2] = 0

        if key[pygame.K_a]:
            if self.vel.x > -limit and "left" not in collison:
                self.acc.x = -ACCELERATION
                self.state[1] = 1
                self.state[0] = 0
                if not self.attack_state[0]:
                    self.direction = False

        if key[pygame.K_d]:
            if self.vel.x < limit and "right" not in collison:
                self.acc.x = ACCELERATION
                self.state[1] = 2
                self.state[0] = 0
                if not self.attack_state[0]:
                    self.direction = True

        if key[pygame.K_l]:
            if not self.dash_key_down and ("left" not in collison or "right" not in collison) and "down" in collison and self.state[1] != 0:
                self.state[5] = 1
                self.state[0] = 0
                self.dash_key_down = True
                self.X_INITIAL = self.position.x
                self.INITIAL_direction = self.direction

        if key[pygame.K_j]:
            if "down" in collison and self.state[1] > 0 and not self.attack_key_down:
                self.attack_state = [1, 0, 0]
                self.attack_key_down = True

        if self.state[1] == 0 and self.state[4] == 0:
            if self.vel.x != 0:
                if self.vel.x < 0:
                    self.vel.x += 0.25 * ACCELERATION
                else:
                    self.vel.x -= 0.25 * ACCELERATION
            if self.vel.y != 0:
                if self.vel.y < 0:
                    self.vel.y += 0.25 * ACCELERATION
                else:
                    self.vel.y -= 0.25 * ACCELERATION
            self.vel.x = self.vel.x.__round__(1)
            self.vel.y = self.vel.y.__round__(1)

    def gravity(self, collision):
        if self.vel.y < 10 and self.state[2] == 0 and "down" not in collision:
            self.acc.y += 0.5 * ACCELERATION


    def dash_deceleration(self, wall_collision):
        if self.state[5] == 1:
            if self.state[1] == 1:
                if self.vel.x < 5:
                    self.acc.x = -10 * ACCELERATION
                    if self.X_INITIAL - self.position.x >= 300 or wall_collision or self.direction:
                        self.state[5] = 0
                        self.vel.x = -2.5
            elif self.state[1] == 2:
                if self.vel.x > -5:
                    self.acc.x = 10 * ACCELERATION
                    if self.position.x - self.X_INITIAL >= 300 or wall_collision or not self.direction:
                        self.state[5] = 0
                        self.vel.x = 2.5

    def jump_deceleration(self, wall_collision):
        if self.state[2]:
            self.acc.y = -1

            if (self.Y_INITIAL - self.position.y) >= 60 or "left" in wall_collision or "right" in wall_collision:
                self.state[2] = 0

    def update(self):
        wall_collision = self.wall_collision()
        self.movement_input(wall_collision)

        self.dash_deceleration(wall_collision)



        self.gravity(wall_collision)

        self.jump_deceleration(wall_collision)


        self.vel += self.acc


        if "left" in wall_collision or "right" in wall_collision or "down" in wall_collision:
            self.jumps_options = 2
        self.acc = pygame.math.Vector2(0, 0)

        # 0:idle, 1: moving, 2: jumping, 3: falling, 4:fast-falling, 5:dashing
        # sprites = [idle, run, jump, fall, fast-fall, re-idle, re-run, re-jump, re-fall, re-fast-fall]
        self.animate(wall_collision, self.sheets, self.vel, self.state, self.direction)
        self.rect = self.image.get_rect()
        if self.attack_state:
            self.Get_hitbox()
        self.position += self.vel
        self.position.y += 2
        self.rect.center = self.position
        self.surface.blit(self.image, self.rect)







class UserInterface:

    def __init__(self):
        self.size = pygame.display.Info()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.pgwindow = Window.from_display_module()
        self.clock = pygame.time.Clock()
        self.connection = None
        self.option = False
        self.stop = False
        self.RES_SET = 0
        self.surface = pygame.Surface(RESOLUTIONS[self.RES_SET])
        self.online = True
        self.wait = True
        self.start = True
        self.current = 0
        self.characterChoice = True
        self.run = True
        self.online_image = pygame.image.load("sprites/online_test_screen.png").convert()
        self.offline_image = pygame.image.load("sprites/Offline_test_screen.png").convert()
        self.tplay = Tab(self.surface, tab_Colour, tab_selectColour, 10, 10, t_WIDTH, t_HEIGHT, "play", self.play)
        self.toption = Tab(self.surface, tab_Colour, tab_selectColour, 10, 60, t_WIDTH, t_HEIGHT, "options", self.options)
        self.texit = Tab(self.surface, tab_Colour, tab_selectColour, 10, 110, t_WIDTH, t_HEIGHT, "exit", self.screen_exit)
        self.tChange_mode = Tab(self.surface, tab_Colour, tab_selectColour, 10, 10, t_WIDTH, t_HEIGHT, "change game mode", self.change_game_mode)
        self.tcharacter = Tab(self.surface, tab_Colour, tab_selectColour, 10, 60, t_WIDTH, t_HEIGHT, "change character", self.change_character)
        self.tresolution = Tab(self.surface, tab_Colour, tab_selectColour, 10, 110, t_WIDTH, t_HEIGHT, f"resolution: {WIDTH}:{HEIGHT}", self.change_resolution)
        self.tabs = [self.tplay, self.toption, self.texit]


    def tab_control(self):
        for t in self.tabs:
            if self.tabs.index(t) == self.current:
                t.hover()
            else:
                t.draw()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.screen_exit()
            if event.type == pygame.KEYDOWN:
                key = pygame.key.get_pressed()
                if key[pygame.K_DOWN]:
                    if self.current < len(self.tabs)-1:
                        self.current += 1
                    else:
                        self.current = 0
                if key[pygame.K_UP]:
                    if 0 < self.current:
                        self.current -= 1
                    else:
                        self.current = len(self.tabs)-1
                if key[pygame.K_RETURN] or key[pygame.K_j] or key[pygame.K_SPACE]:
                    self.tabs[self.current].func()

    def change_resolution(self):
        if self.RES_SET < len(RESOLUTIONS)-1:
            self.RES_SET += 1
        else:
            self.RES_SET = 0
        self.tresolution.message = f"resolution {RESOLUTIONS[self.RES_SET][0]}:{RESOLUTIONS[self.RES_SET][1]}"
        if RESOLUTIONS[self.RES_SET] == (self.size.current_w, self.size.current_h):
            self.screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
        else:
            self.screen = pygame.display.set_mode(RESOLUTIONS[self.RES_SET])
            self.pgwindow = Window.from_display_module()
            self.pgwindow.position = (0, 25)


    def play(self):
        self.start = False
        self.run = False

    def options(self):
        self.option = True
        self.texit.rect.y = 160
        self.tabs = [self.tChange_mode, self.tcharacter, self.tresolution, self.texit]

    def change_game_mode(self):
        self.online = not self.online

    def change_character(self):
        self.characterChoice = not self.characterChoice

    def screen_exit(self):
        if self.option:
            self.option = False
            self.texit.rect.y = 110
            self.current = 2
            self.tabs = [self.tplay, self.toption, self.texit]
        else:
            self.run = False
            self.stop = True

    def wait_screen(self):
        self.connect_to_server()
        while self.wait:
            self.screen.fill("black")
            self.screen.blit(pygame.font.SysFont("Arial", 25).render("waiting for other players", True, "white"), (5, 5))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                data = self.connection.recv(1024).decode()
                if not data:
                    pass
                else:
                    print(data)
                    data = json.loads(data)
                    if data[0]["COMMAND"] == "SET":
                        if data[0]["DATA"][0] == "WAIT":
                            self.wait = False
            pygame.display.update()

    def connect_to_server(self):
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connection.connect((IP_ADDRESS, PORT))


    def main_loop(self):

        while self.run:
            self.clock.tick(30)

            if self.online:
                self.surface.blit(self.online_image, (0, 0))
            else:
                self.surface.blit(self.offline_image, (0, 0))

            self.tab_control()
            self.screen.blit(pygame.transform.scale(self.surface, RESOLUTIONS[self.RES_SET]), (0,0))
            pygame.display.update()




























































