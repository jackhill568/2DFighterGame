import socket
import time

from configs import IP_ADDRESS, PORT
from Online import Server_game
import json

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((IP_ADDRESS, PORT))
s.listen(10)
wait = True
clients = []


def send_to_client(message, client):
    client["connection"].send(json.dumps([message]).encode())


def setup():

    while len(clients) < 2:
        client_connection, client_address = s.accept()
        print("new connection at ", client_address)
        clients.append({"connection": client_connection, "characterChoice": True})

    for client in clients:
        send_to_client({"COMMAND": "SET", "DATA": ["WAIT", "FALSE"]}, client)


if __name__ == '__main__':
    setup()
    game = Server_game(clients)
    time.sleep(1)
    while game.game:
        game.main_loop()


    s.close()
